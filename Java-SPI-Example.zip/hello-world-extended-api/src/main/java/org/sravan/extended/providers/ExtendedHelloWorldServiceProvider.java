package org.sravan.extended.providers;

import org.sravan.spi.HelloWorldService;

public class ExtendedHelloWorldServiceProvider implements HelloWorldService {

	@Override
	public void sayHello() {
		System.out.println("Hello World exteded");
	}
}