package org.sravan;

import java.util.Iterator;
import java.util.ServiceLoader;

import org.sravan.spi.HelloWorldService;

public class App 
{
    public static void main( String[] args )
    {
		ServiceLoader<HelloWorldService> loader =ServiceLoader.load(HelloWorldService.class);
		Iterator<HelloWorldService> iter = loader.iterator();
		while(iter.hasNext()){
			iter.next().sayHello();
		}
    }
}