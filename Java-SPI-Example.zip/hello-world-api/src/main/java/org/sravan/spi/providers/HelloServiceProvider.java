package org.sravan.spi.providers;

import org.sravan.spi.HelloWorldService;

public class HelloServiceProvider implements HelloWorldService{

	@Override
	public void sayHello() {
		System.out.println("Hello World");
	}

}