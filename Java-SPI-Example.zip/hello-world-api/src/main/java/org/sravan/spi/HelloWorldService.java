package org.sravan.spi;

public interface HelloWorldService {
		public void sayHello();
}